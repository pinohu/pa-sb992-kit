# Template E — Telemarketer Registration Checklist

> DISCLAIMER — NOT LEGAL ADVICE. General information from Act Section 3 (73 P.S. Section 2243, as amended by Act 47 of 2026) and the Act's registration-mechanics section (73 P.S. Section 2244, which SB 992 does not amend). Registration determinations are fact-specific; the exemption paragraphs carry detailed multi-part conditions that this checklist only summarizes. **Do not self-certify an exemption from this checklist.** The burden of proving an exemption is on the person claiming it (Act Section 8). Final determination: your Pennsylvania attorney.

## Step 1 — Are you in the Act at all?

You are a "telemarketer" if you (or your business), in connection with telemarketing, initiate or receive telephone calls or messages to or from a residential, business, or wireless subscriber in Pennsylvania — or you are located in Pennsylvania when such calls or messages are initiated or received. A "telemarketing business" is a person or business that is or has engaged in the business of telemarketing (a plan, program, or campaign involving more than one telephone solicitation).

- [ ] We initiate outbound calls/texts/voicemails that solicit sales to PA subscribers → continue to Step 2.
- [ ] We only receive inbound calls/messages in connection with purchases → STILL continue: Section 3(b) makes it unlawful to initiate OR RECEIVE while unregistered if registration was required.
- [ ] Our calls/messages never solicit consumer goods or services (pure service/transactional, within the definition's exclusions) → note category (13) in Step 3, and document the analysis with counsel.

## Step 2 — The registration rule

Unless an exemption applies, a telemarketer — or the telemarketing business employing the telemarketer — must register with the **Office of Attorney General at least 30 days before** offering consumer goods or services for sale through any medium (Act Section 3(a)).

- [ ] The 30-day clock runs BEFORE you start, not before the law's effective date. If you determine you must register, file immediately — every day unregistered is exposure.
- [ ] Special rule: a business providing telemarketing services to other entities under the same ownership or control for **less than five years** must register notwithstanding other provisions.
- [ ] Licensed/registered persons: Section 3(a) does not apply to a person or business licensed by or registered with a federal or Commonwealth agency **acting within the scope** of that license or registration. Out-of-scope solicitation loses this cover.

## Step 3 — Walk the 13 exemption categories (Act Section 3(b.1))

Check any that might apply — then have counsel test the FULL conditions of each (the shorthand below omits most conditions):

- [ ] (1) Catalog sellers (multi-part test: page count, multi-state distribution, annual issuance, circulation threshold, and more)
- [ ] (2) Sales completed only at a later face-to-face meeting, or literature sent without prepayment (with a payment-collection carve-out)
- [ ] (3) Book / video / record clubs and negative-option plans
- [ ] (4) Business-to-business sellers (3+ years under the same name; 50%+ of dollar volume from repeat sales to existing businesses)
- [ ] (5) Federally or Commonwealth licensed/certificated/registered businesses acting within scope
- [ ] (6) Enumerated nonprofits — educational institutions, hospitals, public nonprofit libraries, nonprofit senior centers/nursing homes, bona fide PTA/PTOs, congressionally chartered corporations audited by the Department of Defense, charities receiving $25,000/year or less (cover lost if an unregistered professional fundraising counsel or solicitor is used)
- [ ] (7) Sellers soliciting their own prior purchasers (enterprise operating 3+ years under the same name)
- [ ] (8) Newspaper / magazine / periodical solicitors (publisher 2+ years; seller is an employee/agent; cost and quantity disclosed)
- [ ] (9) Pennsylvania retail establishments (2+ years under the same name; products/services offered at the establishment; majority of business transacted at the physical location)
- [ ] (10) Telemarketing-service providers (5+ years under same ownership/control; 75% of gross telemarketing revenue from contracts with exempt persons)
- [ ] (11) Food / produce sellers (sales of $500 or less; 2+ years under the same name)
- [ ] (12) SEC-registered or exempt issuers and subsidiaries (15 U.S.C. Section 78l)
- [ ] (13) NEW — anyone not engaged in telemarketing because their calls or messages do not meet the definition of "telephone solicitation"

Outcome of the walk:
- [ ] An exemption clearly applies and counsel concurs in writing → file the determination with your compliance records; re-test on any change of business model.
- [ ] No exemption, or any doubt → register (Step 4).

## Step 4 — Register (mechanics under the underlying Act)

> [UNVERIFIED against the post-Act 47 consolidation.] The figures below come from 73 P.S. Section 2244, which SB 992 does not amend, as verified in the pre-Act 47 consolidated Act. Confirm the current form, fee, and bond instructions with the Office of Attorney General before filing.

- [ ] Registration application filed with the Office of Attorney General (biennial registration).
- [ ] Application fee: **$500** (biennial) [UNVERIFIED — see note above].
- [ ] Surety bond: **$50,000**, continuous term — or $50,000 in cash, a certificate of deposit, or government bonds in lieu [UNVERIFIED — see note above].
- [ ] Calendar the renewal date and the bond's continuity (a lapsed bond is a lapsed registration posture).
- [ ] Exposure note: failure to register is a **misdemeanor of the second degree** under the underlying Act — this is the one criminal provision in this area of law; treat the filing as non-optional once the determination is made.
- [ ] Current AG forms, processing times, and any online filing path: confirm directly with the OAG — administrative practice is not stated in the statute. [NOT IN TEXT]
