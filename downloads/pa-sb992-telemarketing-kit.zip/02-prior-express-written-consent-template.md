# Template A — Prior Express Written Consent Agreement

> DISCLAIMER — NOT LEGAL ADVICE. This template is general information, not legal advice. It is structured around the four criteria in the definition of "prior express written consent" in Pennsylvania's Telemarketer Registration Act, Section 2 (as amended by Act 47 of 2026). It has not been reviewed for your business, your industry, or your other legal obligations (including the federal TCPA and FCC rules, which impose their own consent requirements). Have a licensed Pennsylvania attorney review and approve your final consent language before you use it.

## Why this template exists

Under the Act, an agreement counts as prior express written consent only if it: (1) identifies the telephone number authorized; (2) clearly and conspicuously discloses consent to receive telephone solicitations, including a robocall or text message; (3) states that consent is not a condition of purchasing property or consumer goods or services; and (4) is signed by the called party (electronic or digital signature per the federal E-SIGN Act counts). A robocall without this consent is unlawful (Act Section 5(a)(11)), and any communication made WITH this consent is excluded from "telephone solicitation" entirely — which also takes it outside the quiet-hours and do-not-call provisions. Do not obtain consent through any unfair or deceptive practice: that is independently unlawful (Act Section 5(a)(12)).

## The agreement (fill in every bracket)

---

**Consent to Receive Calls and Text Messages**

I agree that [SELLER LEGAL NAME] ("Seller") may send or cause to be sent telephone solicitations — **including robocalls (calls using an automated dialing system delivering prerecorded or artificial voice) and text messages** — to me at the following telephone number:

**Telephone number: [NUMBER]**

I understand that:

- My consent is **not a condition of purchasing** any property, goods, or services.
- Messages and calls may be sent using an automated system. Message and data rates may apply.
- I may revoke this consent at any time — for text messages, by replying STOP, QUIT, END, REVOKE, OPT OUT, CANCEL, or UNSUBSCRIBE; for calls, by telling the caller or contacting Seller at [REVOCATION CONTACT — phone/email/address].
- Consent applies to Seller only. It does not authorize any other business to contact me.

Signature: ______________________________  Date: ______________

Printed name: ______________________________

[For electronic capture: replace the signature block with your e-signature mechanism and record the audit trail described in the capture notes below.]

---

## Capture notes by channel

### Web form
- The consent language must appear clearly and conspicuously at the point of capture — not behind a link, not in pre-checked fine print. A pre-checked box undermines both the "clear and conspicuous" criterion and the Section 5(a)(12) deception prohibition.
- Use an unchecked checkbox or an explicit signature/acknowledgment action tied to the phone-number field.
- Store, for every consent: the exact language version shown, the full text or screenshot of the form, timestamp, IP address, the number entered, and the signature/acknowledgment record. This is your E-SIGN evidence and your burden-of-proof file (the burden of proving an exclusion is on you — Act Section 8).

### Paper form (in store / at point of sale)
- Use the agreement above as a standalone block ABOVE the signature line — never fold consent into a general terms signature without the separate disclosure.
- File the signed original (or a legible scan) keyed to the phone number, and log it in the consent log (Template 07) the same day.

### Recorded line / verbal-to-written confirmation
- A purely verbal "okay" is NOT prior express written consent. If a customer agrees by phone, follow up with a written confirmation (text or email) that presents this agreement and captures an affirmative e-signature or reply-based acknowledgment — and do not send marketing messages until that written artifact exists.

### Purchased or rented lists
- Consent runs to a named seller. A third party's consent file for a different seller does not authorize your robocalls, and does not exclude your messages from "telephone solicitation." Do not buy "consented leads" for automated outreach without counsel reviewing the consent chain.

## Version control

- Date this template's language version and keep retired versions. Your consent records are only as strong as your ability to show WHICH language each person agreed to.
- If you change the disclosure text materially, re-capture consent under the new version before relying on it for robocalls.
