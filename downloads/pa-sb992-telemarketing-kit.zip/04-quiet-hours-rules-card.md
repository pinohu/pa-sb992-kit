# Template C — Quiet-Hours Rules Card (post this where campaigns are built)

> DISCLAIMER — NOT LEGAL ADVICE. General information from Act Sections 5(a)(1) and 5(a)(10) (as amended by Act 47 of 2026). Items marked [PRACTICE STANDARD] are this kit's recommended operating rules where the Act's text is silent — not quotations of the statute. Have counsel confirm your final settings.

## The law (Act Section 5(a)(1) and (a)(10))

It is unlawful to initiate or cause to be initiated:

- A telephone solicitation **on a Sunday** — all day, no exceptions in the text.
- A telephone solicitation **after 7:00 p.m. or before 9:00 a.m.** — any day.
- A telephone solicitation or message **on a legal holiday**.

"Telephone solicitation" = live calls, autodialed calls, AI/agent voice calls, prerecorded calls, **text messages**, voicemails, and **ringless voicemails** sent to solicit sales. If it pitches, these hours govern it.

## The lawful window

**Monday–Saturday, 9:00 a.m. – 7:00 p.m., excluding legal holidays.**

Note the difference from federal law: the TCPA window is 8 a.m.–9 p.m. Pennsylvania closes two hours earlier. If any platform is still set to federal hours, it is wrong for PA.

## Practice standards where the text is silent

- **Whose clock?** [PRACTICE STANDARD] The Act does not name a time zone. Use the **recipient's local time** — the conservative rule law firms recommend. A 6:45 p.m. send from Erie to a recipient in a later time zone can be a 7:45 p.m. violation there.
- **Which holidays?** [PRACTICE STANDARD] "Legal holiday" is **not defined in SB 992**. Do not trust a holiday list attributed to this Act. Block, at minimum, the legal holidays observed by the Commonwealth of Pennsylvania and the federal holidays falling on your campaign calendar — and have counsel confirm the list annually.
- **Scheduled and queued sends count.** A message you queued at noon that a platform delivers at 7:05 p.m. was "initiated" into a prohibited window as a practical matter. Set hard send-window cutoffs inside every platform, with a buffer — stop initiating by 6:45 p.m. recipient-local.
- **Consented communications.** A call or message made with the recipient's prior express written consent is excluded from "telephone solicitation," so the quiet hours keyed to solicitation do not apply to it. Consent records are the proof — no artifact, no exclusion.

## Dialer / platform settings checklist

- [ ] Send window set to 09:00–19:00, recipient-local time zone per contact.
- [ ] Sundays blocked entirely at the platform level (not by campaign habit).
- [ ] Legal-holiday blocklist loaded for the current year and set to auto-block.
- [ ] Initiation cutoff buffered (no new sends after 18:45 recipient-local).
- [ ] Ringless voicemail and voicemail-drop jobs bound by the same window as calls.
- [ ] Text scheduling tools audited — many default to immediate send regardless of hour for API-triggered messages.
- [ ] After-hours inbound replies handled by a non-solicitation auto-response only; no promotional content in off-hours messages.
- [ ] Quarterly re-check: platforms reset settings on updates; verify the window after every vendor change.
