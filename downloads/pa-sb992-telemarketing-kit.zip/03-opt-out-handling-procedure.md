# Template B — Opt-Out Handling Procedure

> DISCLAIMER — NOT LEGAL ADVICE. This procedure is general information, not legal advice. It operationalizes Act Sections 5(a)(2) and 5.2(l) (as amended by Act 47 of 2026) and notes where federal rules differ. Have a licensed Pennsylvania attorney review your final procedure.

## The rules this procedure implements

- A person may stop telephone solicitation TEXT messages by replying "STOP," "QUIT," "END," "REVOKE," "OPT OUT," "CANCEL," or "UNSUBSCRIBE" (Act Section 5(a)(2)). Separately, ANY prior statement that a person does not wish to receive solicitations from you — any wording, any channel — prohibits further solicitation of that person.
- SB 992 states no deadline for honoring a text opt-out. [NOT IN TEXT.] The federal FCC rule allows up to 10 business days for revocation of consent under the TCPA (47 C.F.R. Section 64.1200(a)(10)) — that is a federal ceiling, not a Pennsylvania safe harbor, and it does not apply to robocalls under PA law (see below). **House standard: suppress immediately; same business day is the outer limit.**
- ROBOCALLS are stricter: the called party must be "immediately" taken off the call list (Act Section 5.2(l)).
- The Act's safe harbor protects an erroneous contact only if you established and implemented written procedures, trained personnel, and maintained and recorded do-not-contact lists (Act Section 5(a)(2)). This document + your log (Template 07) are that evidence.

## Procedure

### 1. Recognize (every channel, every wording)
Configure every sending system to detect, at minimum, these exact replies to text messages:
STOP · QUIT · END · REVOKE · OPT OUT · CANCEL · UNSUBSCRIBE

Also route to a human review queue any reply expressing refusal in other words (for example: "stop texting me," "remove me," "leave me alone," "no more messages"). A clear statement in any words ends solicitation to that person.

For voice: any statement during a call that the person wants no more calls, or wants the call ended, is an opt-out — the agent ends the call immediately (Act Section 5(a)(8)) and records the number.

### 2. Suppress (immediately)
- [ ] The number is added to the master suppression list the moment the opt-out is received (automated for keyword replies; same business day for human-reviewed items).
- [ ] Suppression propagates to EVERY sending system: dialer, texting platform, ringless voicemail vendor, CRM campaign tools, and any agency sending on your behalf. One list of record; vendors pull from it or receive it before every campaign.
- [ ] Suppression is by NUMBER and by PERSON where identifiable — a new number from the same person does not reset their refusal.
- [ ] Suppression never expires on its own. Removal requires a new, documented prior express written consent from that person.

### 3. Confirm (once, then silence)
- Texts: a single confirmation message with no marketing content (for example, "You have been unsubscribed and will receive no further marketing texts from [Seller].") is standard practice — then no further solicitation messages, ever.
- Never require the person to do anything else — no forms, no calls, no written consent as a condition of opting out (for robocalls this is explicit: Act Section 5.2(l)(1)(iii)).

### 4. Record (every opt-out, in Template 07)
Log: date/time received, number, channel, the exact wording or method, date/time suppression was applied in each system, and who/what applied it. Retain logs with your consent records.

### 5. Robocall-specific mechanics (Act Section 5.2(l)) — verify before any robocall campaign
- [ ] The opt-out mechanism is announced at the BEGINNING of the call.
- [ ] An automated interactive voice/key-press opt-out is available within TWO SECONDS of disclosing the caller's name and the name of the person/entity on whose behalf the call is made — and remains available throughout the call.
- [ ] Opting out takes the party off the call list IMMEDIATELY.
- [ ] No written consent is required as a condition of opting out.
- [ ] Voicemail-dropped robocalls include a TOLL-FREE callback number connecting directly to the automated opt-out mechanism, which automatically records the number to your do-not-call list.

### 6. Audit (monthly, and before every campaign)
- [ ] Send test messages from a test number: reply with each of the seven keywords, one per test cycle, and confirm suppression in every system.
- [ ] Send one plain-language refusal ("Please stop contacting me") and confirm it reaches the review queue and results in suppression.
- [ ] Sample 10 numbers from the suppression list and confirm none appear in any active campaign audience.
- [ ] Reconcile vendor audiences against the master suppression list; get vendor attestation in writing.
- [ ] File the audit (date, tester, results, fixes) with your compliance records.

### 7. Error response
If a solicitation reaches a suppressed number: stop, document the error and its cause, fix the system gap, and preserve the record — the Act's safe harbor turns on written procedures, training, recorded lists, and genuine error. An undocumented error looks like a practice.
