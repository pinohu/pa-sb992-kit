# Template D — Do-Not-Call Hygiene Checklist

> DISCLAIMER — NOT LEGAL ADVICE. General information from Act Section 5.2 (as amended by Act 47 of 2026). Have a licensed Pennsylvania attorney confirm your do-not-call process.

## The duties (Act Section 5.2)

- Never initiate a telephone solicitation to a subscriber enrolled on the do-not-call list maintained by the list administrator. The bar applies **30 days after** the quarterly list that first contains the subscriber is issued (Section 5.2(a)) — your scrubbing must run inside that window.
- **Quarterly**, obtain the list of enrolled Pennsylvania subscribers (residential, business, and wireless) — or use a service provider that has quarterly obtained it and will use it (Section 5.2(b)).
- Use the list **only** to remove subscribers from solicitation lists. Any other use is prohibited (Section 5.2(g)).
- Pennsylvania enrollment feeds the national registry mechanism — but scrubbing only the federal list is not the same as obtaining the PA list. Do both.

## Quarterly cycle checklist

- [ ] Obtain this quarter's PA do-not-call list (directly, or written confirmation from your provider that they obtained and applied it — keep the confirmation).
- [ ] Scrub every active and planned campaign audience against the new list before the 30-day effectiveness window closes.
- [ ] Record the scrub: list version/issue date, scrub date, tool or provider used, number of records removed per campaign.
- [ ] Confirm your internal suppression list (Template 03) was applied IN ADDITION to the official list — they are different lists with different sources.
- [ ] Confirm no team or vendor used the DNC data for anything other than suppression (no enrichment, no lead scoring, no resale).

## Standing hygiene rules

- [ ] Every campaign audience is scrubbed as close to send time as operations allow — a scrub from last quarter does not cover this quarter's enrollees.
- [ ] Numbers are never "rested and retried." Removal is permanent unless the person gives new prior express written consent (Template 02).
- [ ] Wrong numbers and reassigned numbers are removed on first notice and logged — soliciting the new subscriber at an old customer's number has no exclusion behind it.
- [ ] Vendors and agencies sending on your behalf certify their scrub cadence in writing, per campaign. "We handle compliance" is not a certification.
- [ ] Records kept per campaign: audience source, consent basis by segment, scrub evidence, send window, opt-out results (Template 07). If it is not logged, it did not happen — and the burden of proof on exclusions and defenses sits with you (Act Section 8).
